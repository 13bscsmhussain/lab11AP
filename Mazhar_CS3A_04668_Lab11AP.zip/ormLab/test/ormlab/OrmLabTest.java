/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ormlab;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author mhussain.bscs13seecs
 */
public class OrmLabTest {
    
    public OrmLabTest() {
    }
    
    

    /**
     * Test of businessLogicAdd method, of class OrmLab.
     */
    @Test
    public void testBusinessLogicAdd() {
        System.out.println("businessLogicAdd");
        int expResult = 2;
        int out= OrmLab.businessLogicAdd();
        assertEquals(expResult, out);
        
        
    }

    /**
     * Test of businessLogicRetrive method, of class OrmLab.
     */
    @Test
    public void testBusinessLogicRetrive() {
        System.out.println("businessLogicRetrive");
        int expResult = 1;
        int out= OrmLab.businessLogicRetrive();
        assertEquals(expResult, out);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of main method, of class OrmLab.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        OrmLab.main(args);
        // TODO review the generated test code and remove the default call to fail.
     
    }
    
}
