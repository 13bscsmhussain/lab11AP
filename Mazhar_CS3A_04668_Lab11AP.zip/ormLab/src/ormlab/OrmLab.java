 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ormlab;
import attendance.ui.AttendanceSystem;
import java.util.Scanner;
import java.util.Set;
import pk.edu.nust.seecs.gradebook.entity.*;
import pk.edu.nust.seecs.gradebook.util.*;
import pk.edu.nust.seecs.gradebook.dao.*;
import attendance.entity.*;
import java.util.Date;
import java.util.HashSet;
import attendance.util.HibernateUtil;



/**
 *
 * @author mhussain.bscs13seecs
 */
public class OrmLab {

    /**
     * @param args the command line arguments
     */
    
   //adding teacher and students
 public static int var = 0;
    
    //adds the data using both the given appplication using business logic add class
  public static int Add_data(){
        Date date_ = new Date();
        date_.setYear(2016);
        date_.setMonth(2);
        
        Date date_2 = new Date();
        date_2.setYear(2016);
        date_2.setMonth(10);
        
        AttendanceSystem Atendance_sys = new AttendanceSystem();
		
		
		//adding the teachers
       Teacher_1 = new  pk.edu.nust.seecs.gradebook.entity.Teacher("Ma'm Saima");
       
       Teacher_2 = new  pk.edu.nust.seecs.gradebook.entity.Teacher("Sir Fahad Satti");
       
        //adding  new courses
        pk.edu.nust.seecs.gradebook.entity.Course course_1,course_1;
        
       course_1 = new pk.edu.nust.seecs.gradebook.entity.Course("Accounting", date_, date_2, 4);
       
       course_1 = new pk.edu.nust.seecs.gradebook.entity.Course("AP", date_, date_2, 4);
        
       pk.edu.nust.seecs.gradebook.entity.Teacher Teacher_1,Teacher_2;
        
       //three students
       
        CourseDao course_add = new CourseDao();
        course_add.course_add(null);
         
         
         pk.edu.nust.seecs.gradebook.entity.Student student_1,student_2,student_3;
         student_1 = new pk.edu.nust.seecs.gradebook.entity.Student();
         student_2 = new pk.edu.nust.seecs.gradebook.entity.Student();
           student_3 = new pk.edu.nust.seecs.gradebook.entity.Student();
         
           //set the students
         student_1.setName("Mazhar");
         student_2.setName("Hussain");
         student_3.setName("Safdar");
         var = 2;
         
         return var;
    }
    
    public static int Retrieve_data(){
        
      AttendanceSystem Atendance_sys = new AttendanceSystem();
       
        pk.edu.nust.seecs.gradebook.entity.Course course_1,course_1;
        
       course_1 = new pk.edu.nust.seecs.gradebook.entity.Course();
       
       pk.edu.nust.seecs.gradebook.entity.Teacher Teacher_1,Teacher_2;
        
       Teacher_1 = new  pk.edu.nust.seecs.gradebook.entity.Teacher();
       
       
       String CourseRetrive = course_1.getClasstitle();
       int Course_ID = course_1.getCourseid();
       int Course_credithrs = course_1.getCreditHours();
       pk.edu.nust.seecs.gradebook.entity.Teacher teacherget = course_1.getTeacher();
       
       //list of three students
       
        CourseDao course_add = new CourseDao();
        
         pk.edu.nust.seecs.gradebook.entity.Student student_1,student_2,student_3;
         student_1 = new pk.edu.nust.seecs.gradebook.entity.Student();
         
         String studentName = student_1.getName();
         int studnet2 = student_1.hashCode();
         
         if(studnet2!=0){
         var = 1;
         }
       return var;
         
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanonput = new Scanner(System.in);
        System.out.println("       Welcome...        "+"\n");  
        System.out.println("       Press 1 to enter data  ");
        System.out.println("       Press 2 to get the stored  data ");
         int i = scanonput.nextInt();
        
         if(i == 1){
       int g =  Add_data();
         }
         
         if(i == 2){
          int k = Retrieve_data();
         }
            
    }    
}
